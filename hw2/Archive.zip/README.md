### README

The code for the programming portion is in agent.py

A class CartPole is defined, which is responsible for implementing evolutionary search, and running a given policy for multiple episodes.
Code for grid search is also included, but the actual process of doing several rounds of grid search is manual. The grid search for the final finegrained set of hyperparameters is included in the code. 

